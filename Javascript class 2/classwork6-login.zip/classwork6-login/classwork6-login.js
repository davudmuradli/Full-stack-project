
function any() {
    const loginform = document.getElementById("login-form")
    const loginsubmit = document.getElementById('form-submit')
    const error = document.getElementById("errortxt")
    
    loginform.addEventListener("submit",(e) => {
        e.preventDefault();
        const username = loginform.username.value;
        const password = loginform.password.value;
    
        if(username === 'your_email' && password === "password123"){
            console.log("Welcome to the club buddy!")
            error.style.opacity = 0;
        }
        else{
            error.style.opacity= 1;
        }
    })

}










